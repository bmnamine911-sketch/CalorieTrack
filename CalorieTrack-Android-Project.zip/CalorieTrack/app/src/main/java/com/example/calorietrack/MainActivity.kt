package com.example.calorietrack

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var result: TextView
    private var imageCapture: ImageCapture? = null
    private val foods = linkedMapOf("بيض" to 155, "خبز" to 265, "دجاج مشوي" to 165, "أرز مطبوخ" to 130, "موز" to 89, "تفاح" to 52)

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else Toast.makeText(this, "خاص السماح للكاميرا", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24); setBackgroundColor(0xFF07131A.toInt()) }
        val title = TextView(this).apply { text = "🔥 CalorieTrack"; textSize = 28f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0,0,0,12) }
        val sub = TextView(this).apply { text = "صوّر الأكل وخذ تقديراً للسعرات"; textSize = 16f; setTextColor(0xFFA9B7BD.toInt()) }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        root.addView(title); root.addView(sub)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        val snap = Button(this).apply { text = "📸 تصوير الأكل"; setOnClickListener { takePhoto() } }
        val choose = Button(this).apply { text = "🍽️ اختيار الأكل وحساب السعرات"; setOnClickListener { showFoodDialog() } }
        result = TextView(this).apply { text = "صوّر أولاً ثم اختر الطعام للحصول على تقدير.\nملاحظة: الصورة وحدها لا تعطي كمية دقيقة دائماً."; textSize = 17f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0,18,0,18) }
        root.addView(snap); root.addView(choose); root.addView(result)
        setContentView(root)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera() else permission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUse = androidx.camera.core.Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
            provider.unbindAll(); provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUse, imageCapture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        capture.takePicture(ContextCompat.getMainExecutor(this), object: ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: androidx.camera.core.ImageProxy) { image.close(); result.text = "✅ تم التقاط الصورة. دابا اختار الأكل باش نحسب لك تقدير السعرات." }
            override fun onError(exception: ImageCaptureException) { result.text = "وقع مشكل فالتصوير." }
        })
    }

    private fun showFoodDialog() {
        val names = foods.keys.toTypedArray()
        AlertDialog.Builder(this).setTitle("شنو كاين فالصورة؟").setItems(names) { _, which ->
            val name = names[which]
            val input = EditText(this).apply { hint = "الكمية بالجرام"; inputType = 2; setText("100") }
            AlertDialog.Builder(this).setTitle(name).setMessage("دخل الكمية تقريباً").setView(input).setPositiveButton("حساب") { _, _ ->
                val g = input.text.toString().toDoubleOrNull() ?: 100.0
                val kcal = foods[name]!! * g / 100.0
                result.text = "🔥 ${name}: حوالي ${kcal.toInt()} kcal\nالكمية: ${g.toInt()} g\n\nهذا تقدير تقريبي، لأن الوصفة والكمية وطريقة الطبخ تؤثر على السعرات."
            }.setNegativeButton("إلغاء", null).show()
        }.setNegativeButton("إلغاء", null).show()
    }
}
